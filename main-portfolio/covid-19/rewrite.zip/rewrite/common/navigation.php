<nav>
    <?php echo $nav; ?>
</nav>

<main>