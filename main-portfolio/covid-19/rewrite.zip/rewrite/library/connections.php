<?php

/*
 *Database connections
*/

function acmeConnect() {
    $server = "localhost";
    $database = "covd-19";
    $user = "iClient";
    $password = "i2lQXnAkLCszygcw";
    $dsn = 'mysql:host=' . $server . ';dbname=' . $database;
    $options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

    try {
        $link = new PDO($dsn, $user, $password, $options);        
        return $link;
    } catch (PDOException $exc) {
        echo $exc;
        exit;
    }
}
