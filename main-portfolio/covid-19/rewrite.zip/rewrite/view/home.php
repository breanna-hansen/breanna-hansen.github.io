<!-- Header -->
<?php include $_SERVER['DOCUMENT_ROOT'] . '/covid-19/rewrite/common/header.php'; ?>
<!-- Nav -->
<?php include $_SERVER['DOCUMENT_ROOT'] . '/covid-19/rewrite/common/navigation.php'; ?>

<div>

    <p class="intro">Are we moving closer to normal life and safety? Look at the curve for your state to see where you are in
        the coronavirus life cycle. When the curve for new starts to level off or "flatten" it is an indication that the rate
        of spread in your area is slowing. Public policy makers are looking closely at these curves to inform their decision
        making process.
    </p>
    <div class="stateLinks">
        <?php echo $sidebarMenu; ?>
    </div>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/covid-19/rewrite/common/charts.php'; ?>

</div>

<!-- Footer -->
<?php include $_SERVER['DOCUMENT_ROOT'] . '/covid-19/rewrite/common/footer.php'; ?>