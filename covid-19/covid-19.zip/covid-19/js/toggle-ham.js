function toggleHam() {
    var element = document.getElementById("navigation");
    element.classList.toggle("hide");
  }
