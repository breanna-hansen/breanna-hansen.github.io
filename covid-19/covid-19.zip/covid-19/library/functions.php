<?php

/*
 * This is my helper functions file.
 */

 // insert daily data
function insert_Daily_StateRecord($stateId,$stateName,$Confirmed,$Deceased,$Recovered,$Serious){
    $db = acmeConnect();
    $sql = "INSERT INTO dailydata (stateId, stateName, StatisticDate, Confirmed, Deceased, Recovered, Serious) 
    VALUES(:stateId,:stateName,CURRENT_TIMESTAMP,:Confirmed,:Deceased,:Recovered,:Serious)";
     // The next line creates the prepared statement using the acme connection
     $stmt = $db->prepare($sql);
     // The next line replaces the placeholder in the SQL statement with the actual
    // values in the variables and tells the database the type of data it is
    $stmt->bindValue(':stateId', $stateId, PDO::PARAM_INT);
    $stmt->bindValue(':stateName', $stateName, PDO::PARAM_STR);
    $stmt->bindValue(':Confirmed', $Confirmed, PDO::PARAM_INT);
    $stmt->bindValue(':Deceased', $Deceased, PDO::PARAM_INT);
    $stmt->bindValue(':Recovered', $Recovered, PDO::PARAM_INT);
    $stmt->bindValue(':Serious', $Serious, PDO::PARAM_INT);
    // Use the prepared statement to insert the data
    $stmt->execute();  
    // Close the database interaction
    $stmt->closeCursor();
}

// create state id numbers
function createStateId($stateName) {
    $db = acmeConnect();
    $sql = "INSERT INTO states (stateName) VALUES (:stateName)";
     // The next line creates the prepared statement using the acme connection
     $stmt = $db->prepare($sql);
     // The next line replaces the placeholder in the SQL statement with the actual
    // values in the variables and tells the database the type of data it is
    $stmt->bindValue(':stateName', $stateName, PDO::PARAM_STR);
    // Use the prepared statement to insert the data
    $stmt->execute();  
    // Close the database interaction
    $stmt->closeCursor();
}

// get individual state information by state
function getStateInfo($stateName) {
    $db = acmeConnect();
    $sql = 'SELECT stateId FROM states WHERE stateName = :stateName';
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':stateName', $stateName, PDO::PARAM_STR);
    $stmt->execute();
    $stateInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $stateInfo["stateId"];
}
